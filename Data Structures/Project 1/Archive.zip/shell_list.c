#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#include "shell_list.h"

#define INT_MIN -1000000000
/*
typedef ode{
    long value;
    ode *next;
}Node;
*/
//this re has been defined in shell_list.h

Node *List_Load_From_File(char *filename)
{
  FILE *fptr;
  
  fptr = fopen(filename,"rb");
  if(fptr == NULL)
  {
    fprintf(stderr, "File error: %s \n",filename);
    return NULL;
  }
  
  long buffer;
  int num_elem;
    Node *node_elem = NULL;
  Node* head = NULL;
 
 
  num_elem = (fread(&buffer,sizeof(long),1,fptr));
  if(num_elem)
  {
  head = node_elem = malloc(sizeof(Node));
  node_elem->value = buffer;
  while(num_elem){
  num_elem = fread(&buffer, sizeof(long), 1,fptr);
  if(num_elem)
  {
   Node * next_node = malloc(sizeof(Node));
   next_node->value = buffer;
   node_elem->next = next_node;
   node_elem = next_node;

   }
   }
    node_elem->next = NULL;
}

fclose(fptr);
return head;
}

int List_Save_To_File(char *filename, Node *list)
{
  FILE * fptr = fopen(filename, "wb");
  int check = 0;
   
  if (fptr == NULL)
  {
    return false;
  }
  for(Node*current =list; current!= NULL; current = current->next){
  check += fwrite (&(current->value),sizeof(long),1,fptr);
}
fclose(fptr);
return check;
}
static Node* List_Swap(Node* top, Node* fpar) {
  // par->next != NULL
  if (fpar == NULL) {
    Node * fe = top;
    Node * le = top->next;
    fe->next = le->next;
    le->next = fe;
    return le;
  }

  Node * fe = fpar->next;
  Node * le = fe->next;
  Node * ln = le->next;
  
  bool isFeTop = fe == top;
  bool isLeTop = le == top;

  fpar->next = le;
  le->next = fe;
  fe->next = ln;

  return isFeTop ? le : isLeTop ? fe : top;
}


static Node* List_BubbleSort(Node* n, long *n_comp) {
    
  if (n == NULL || n->next == NULL) return n;
  bool swapped;
  do {
    swapped = false;
    Node * last = NULL;
    if (n->value > n->next->value) {
      n = List_Swap(n, NULL);
      swapped = true;
      (*n_comp)++;
    }
    Node * curr1 = n->next, *prev1 = n;
    for (; curr1->next != last; prev1 = curr1, curr1 = curr1->next) {
      if (curr1->value > curr1->next->value) {
        Node * ccurr = curr1->next;
        n = List_Swap(n, prev1);
        curr1 = ccurr;
        swapped = true;
        (*n_comp)++;
      }
    }
    last = curr1->next;
  } while (swapped);
  return n;
}

Node *List_Shellsort(Node *list, long *n_comp) {
 
    Node * aaja = List_BubbleSort(list,n_comp);
    
    return aaja;
}
